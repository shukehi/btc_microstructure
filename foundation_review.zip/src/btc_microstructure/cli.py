"""Only validate-config is implemented. No network access or environment expansion."""

import argparse
import json
import sys
from collections.abc import Sequence

from pydantic import ValidationError

from .capabilities import pending_capabilities
from .config import ConfigError, config_digest, load_config


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="btc-microstructure")
    commands = parser.add_subparsers(dest="command", required=True)
    validate = commands.add_parser("validate-config", help="validate a local YAML file offline")
    validate.add_argument("path")
    args = parser.parse_args(argv)
    try:
        config = load_config(args.path)
    except ValidationError as exc:
        for error in exc.errors(include_input=False, include_url=False, include_context=False):
            field = ".".join(str(part) for part in error["loc"]) or "config"
            print(f"{field}: {error['msg']}", file=sys.stderr)
        return 1
    except ConfigError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    print(
        json.dumps(
            {
                "status": "CONFIG_VALID",
                "sha256": config_digest(config),
                "runtime_capabilities": {
                    item.name: item.status for item in pending_capabilities(config)
                },
            },
            sort_keys=True,
        )
    )
    return 0
