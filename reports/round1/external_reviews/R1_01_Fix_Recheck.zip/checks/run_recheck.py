"""Independent local rerun; records new logs without overwriting submitted evidence."""
from pathlib import Path
import subprocess, sys, os, json, time, platform, importlib.metadata as md
import xml.etree.ElementTree as ET
BASE=Path(__file__).resolve().parents[1]; PROJECT=BASE/'project'; EV=BASE/'evidence'
ENV=os.environ.copy(); ENV.update(PYTHONPATH=str(PROJECT/'src'), PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
environment={'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'machine':platform.machine(),'working_directory':str(PROJECT),'environment_overrides':{k:ENV[k] for k in ['PYTHONPATH','PYTHONDONTWRITEBYTECODE','PYTEST_DISABLE_PLUGIN_AUTOLOAD']},'dependencies':{}}
for name in ['pydantic','pydantic-core','PyYAML','pytest','ruff','mypy','setuptools','types-PyYAML','pip']:
    try: environment['dependencies'][name]=md.version(name)
    except md.PackageNotFoundError: environment['dependencies'][name]='NOT_INSTALLED'
(EV/'environment.json').write_text(json.dumps(environment,indent=2))
tasks=[
('original_48',[sys.executable,'-m','pytest','-q','-p','no:cacheprovider','tests/unit/test_config.py',f'--junitxml={EV}/original_48.xml'],0),
('default_suite',[sys.executable,'-m','pytest','-q','-p','no:cacheprovider',f'--junitxml={EV}/default_suite.xml'],0),
('independent_15',[sys.executable,'-m','pytest','-q','-p','no:cacheprovider','review/R1_01/checks/test_review_regressions.py',f'--junitxml={EV}/independent_15.xml'],0),
('cli_valid',[sys.executable,'-m','btc_microstructure','validate-config','config/research.example.yaml'],0),
]
for p in sorted((PROJECT/'reports/round1/fix/fixtures').glob('*.yaml')):
    tasks.append(('cli_'+p.stem,[sys.executable,'-m','btc_microstructure','validate-config',str(p.relative_to(PROJECT))],1))
records=[]
for name,cmd,expected in tasks:
    t=time.monotonic()
    proc=subprocess.run(cmd,cwd=PROJECT,env=ENV,text=True,capture_output=True,timeout=40)
    result={'name':name,'command':cmd,'working_directory':str(PROJECT),'returncode':proc.returncode,'expected_returncode':expected,'duration_seconds':round(time.monotonic()-t,3),'log':f'evidence/{name}.log','status':'PASS' if proc.returncode==expected else 'FAIL'}
    (EV/f'{name}.log').write_text('COMMAND: '+json.dumps(cmd)+'\nCWD: '+str(PROJECT)+'\nRETURN_CODE: '+str(proc.returncode)+'\nSTDOUT:\n'+proc.stdout+'\nSTDERR:\n'+proc.stderr)
    xml=EV/f'{name}.xml'
    if xml.exists():
        suites=ET.parse(xml).getroot().findall('testsuite')
        result['junit']={k:sum(int(s.get(k,'0')) for s in suites) for k in ['tests','failures','errors','skipped']}
    if name=='cli_valid' and proc.returncode==0:
        result['parsed_output']=json.loads(proc.stdout)
    if name.startswith('cli_') and expected==1:
        result['field_in_stderr']=name.removeprefix('cli_') in proc.stderr
        result['reason_in_stderr']='must be true' in proc.stderr
        if not result['field_in_stderr'] or not result['reason_in_stderr']:result['status']='FAIL'
    records.append(result)
    (EV/'commands.json').write_text(json.dumps(records,indent=2))
    print(name,proc.returncode,result.get('junit',result.get('parsed_output',{})),flush=True)
print('RESULT',all(x['status']=='PASS' for x in records))
