"""Verify received artifacts without trusting their embedded PASS statuses."""
from pathlib import Path, PurePosixPath
import hashlib, json, zipfile, xml.etree.ElementTree as ET
BASE=Path(__file__).resolve().parents[1]; ROOT=BASE/'project'; EV=BASE/'evidence'; INPUT=BASE.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
checks={}
with zipfile.ZipFile(INPUT/'foundation_review.zip') as old:
    checks['before_snapshots_match_original']={
        '.gitignore':(ROOT/'reports/round1/fix/before/.gitignore.txt').read_bytes()==old.read('.gitignore'),
        'config_models.py':(ROOT/'reports/round1/fix/before/config_models.py.txt').read_bytes()==old.read('src/btc_microstructure/config_models.py')}
    checks['original_test_unchanged']=(ROOT/'tests/unit/test_config.py').read_bytes()==old.read('tests/unit/test_config.py')
with zipfile.ZipFile(INPUT/'R1_01_Independent_Review.zip') as z:
    mapped=[]
    for n in z.namelist():
        if n.endswith('/'):continue
        rel=str(PurePosixPath(n).relative_to('r1_01_independent_review'))
        p=ROOT/'review/R1_01'/rel
        mapped.append({'source':n,'project_path':str(p.relative_to(ROOT)),'matches':p.exists() and p.read_bytes()==z.read(n)})
    checks['original_review_input']={'files':len(mapped),'all_match':all(x['matches'] for x in mapped),'details':mapped}
(EV/'original_review_preserved.json').write_text(json.dumps(checks['original_review_input'],indent=2))
prot=json.loads((ROOT/'reports/round1/fix/protected.json').read_text())
pr=[]
for p,d in prot.items():
    f=ROOT/p
    pr.append({'path':p,'status':('MATCH' if sha(f.read_bytes())==d else 'DIFFERENT') if f.exists() else 'NOT_PACKAGED'})
checks['protected_materials']={'declared':len(pr),'matched':sum(x['status']=='MATCH' for x in pr),'exceptions':[x for x in pr if x['status']!='MATCH']}
checks['hash_lists']={}
for rel in ['reports/round1/preserved.sha256','reports/round1/fix/fixed-implementation.sha256']:
    entries=[]
    for line in (ROOT/rel).read_text().splitlines():
        if not line.strip():continue
        h,p=line.split(maxsplit=1);p=p.lstrip('*');f=ROOT/p
        entries.append({'path':p,'matches':f.exists() and sha(f.read_bytes())==h})
    checks['hash_lists'][rel]={'count':len(entries),'all_match':all(x['matches'] for x in entries),'details':entries}
checks['submitted_junit']={}
for phase in ['before','after']:
    for p in sorted((ROOT/'reports/round1/fix'/phase).glob('*.xml')):
        suites=ET.parse(p).getroot().findall('testsuite')
        checks['submitted_junit'][str(p.relative_to(ROOT))]={k:sum(int(s.get(k,'0')) for s in suites) for k in ['tests','failures','errors','skipped']}
# Verify submitted dependency evidence against submitted lock, not reviewer environment.
locked={}
for line in (ROOT/'requirements-dev.lock').read_text().splitlines():
    if '==' in line:
        name,version=line.split('==',1);locked[name.lower().replace('_','-')]=version
reported=json.loads((ROOT/'reports/round1/fix/after/integrity.json').read_text())['exact_locked_dependencies']
checks['submitted_dependency_evidence_matches_lock']={name:locked.get(name.lower().replace('_','-'))==v['expected']==v['actual'] for name,v in reported.items()}
(EV/'integrity_details.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False))
print('before snapshots:',checks['before_snapshots_match_original'])
print('review input:',checks['original_review_input']['files'],checks['original_review_input']['all_match'])
print('protected materials:',checks['protected_materials'])
for p,d in checks['hash_lists'].items():print(p,d['count'],d['all_match'])
print('dependency evidence:',len(checks['submitted_dependency_evidence_matches_lock']),all(checks['submitted_dependency_evidence_matches_lock'].values()))
